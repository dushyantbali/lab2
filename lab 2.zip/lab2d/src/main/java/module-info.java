module com.example.lab2d {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.sql;


    opens com.example.lab2d to javafx.fxml;
    exports com.example.lab2d;
}